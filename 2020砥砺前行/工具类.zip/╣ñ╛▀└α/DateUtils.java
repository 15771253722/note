

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;

public class DateUtils {
    public static final long millisInDay = 86400000L;
    public static final long millisInHour = 3600000L;
    public static final String YEAR_FORMAT_STR = "yyyy";
    public static final String MONTH_FORMAT_STR = "yyyy-MM";
    public static final String DATE_FORMAT_STR = "yyyy-MM-dd";
    public static final String HOUR_FORMAT_STR = "yyyy-MM-dd HH";
    public static final String MINUTE_FORMAT_STR = "yyyy-MM-dd HH:MM";
    public static final String TIME_FORMAT_STR = "yyyy-MM-dd HH:mm:ss";
    protected static DateFormat DATE_FORMAT;
    protected static DateFormat HOUR_FORMAT;
    protected static DateFormat MINUTE_FORMAT;
    protected static DateFormat TIME_FORMAT;
    protected static DateFormat MONTH_FORMAT;
    protected static DateFormat YEAR_FORMAT;

    public DateUtils() {
    }

    public static Date stringToUtilDate(String str) {
        str = str.replaceAll("/", "-");
        if (null != str && str.length() > 0) {
            try {
                return str.length() == "yyyy".length() ? YEAR_FORMAT.parse(str) : (str.length() == "yyyy-MM".length() ? MONTH_FORMAT.parse(str) : (str.length() == "yyyy-MM-dd".length() ? DATE_FORMAT.parse(str) : (str.length() == "yyyy-MM-dd HH".length() ? HOUR_FORMAT.parse(str) : (str.length() == "yyyy-MM-dd HH:MM".length() ? MINUTE_FORMAT.parse(str) : TIME_FORMAT.parse(str)))));
            } catch (ParseException var2) {
                return null;
            }
        } else {
            return null;
        }
    }

    public static java.sql.Date stringToSqlDate(String str) {
        return stringToUtilDate(str) != null && str.length() >= 1 ? new java.sql.Date(stringToUtilDate(str).getTime()) : null;
    }

    public static Date[] getYears(Date day, int n) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(day);
        cal.add(1, 1 - n);
        Date[] ret = new Date[n];

        for(int i = 0; i < n; ++i) {
            Date year = getStartOfYear(cal.getTime());
            ret[i] = year;
            cal.setTime(nextYear(year));
        }

        return ret;
    }

    public static String getYear(Date day) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(day);
        return cal.get(1) + "";
    }

    public static long getSeconds(Date d) {
        long time = d.getTime();
        return time - time % 1000L;
    }

    public static long getMinutes(Date d) {
        long time = d.getTime();
        return time - time % 60000L;
    }

    public static Date nextWeek(Date date) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(3, 1);
        return c.getTime();
    }

    public static Date preWeek(Date date) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(3, -1);
        return c.getTime();
    }

    public static Date nextMonth(Date now) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(now);
        cal.add(2, 1);
        return cal.getTime();
    }

    public static Date preMonth(Date now) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(now);
        cal.add(2, -1);
        return cal.getTime();
    }

    public static Date nextHours(Date day, int n) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(day);
        cal.add(10, n);
        return getEndOfHour(cal.getTime());
    }

    public static Date nextDay(Date now) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(now);
        cal.add(5, 1);
        return cal.getTime();
    }

    public static Date preDay(Date now) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(now);
        cal.add(5, -1);
        return cal.getTime();
    }

    public static Date preHour(Date now) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(now);
        cal.add(10, -1);
        return cal.getTime();
    }

    public static Date beforeHours(Date now, int hours) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(now);
        cal.add(10, -hours);
        return cal.getTime();
    }

    public static Date nextHour(Date now) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(now);
        cal.add(10, 1);
        return cal.getTime();
    }

    public static Date preYear(Date now) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(now);
        cal.add(1, -1);
        return cal.getTime();
    }

    public static Date nextYear(Date now) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(now);
        cal.add(1, 1);
        return cal.getTime();
    }

    public static Iterator<Date[]> iterate(final Date begin, final Date end) {
        Iterator iter = new Iterator() {
            boolean hasNext = true;
            Date b = (Date)begin.clone();
            Date e = (Date)end.clone();

            public void remove() {
            }

            public Date[] next() {
                Date theEndOfMonth = DateUtils.getEndOfMonth(this.b);
                Date[] r = new Date[2];
                if (theEndOfMonth.after(end)) {
                    this.hasNext = false;
                    r[0] = this.b;
                    r[1] = this.e;
                } else {
                    r[0] = this.b;
                    r[1] = theEndOfMonth;
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(theEndOfMonth);
                    cal.add(13, 1);
                    this.b = cal.getTime();
                }

                return r;
            }

            public boolean hasNext() {
                return this.hasNext;
            }
        };
        return iter;
    }

    public static Date parseDate(String dateStr) {
        try {
            DateFormat e = DATE_FORMAT;
            synchronized(DATE_FORMAT) {
                return DATE_FORMAT.parse(dateStr);
            }
        } catch (ParseException var6) {
            try {
                return MONTH_FORMAT.parse(dateStr);
            } catch (ParseException var4) {
                return null;
            }
        }
    }

    public static String format(Date date) {
        try {
            DateFormat e = DATE_FORMAT;
            synchronized(DATE_FORMAT) {
                return DATE_FORMAT.format(date);
            }
        } catch (Exception var5) {
            return null;
        }
    }

    public static String format(Date date, String format) {
        try {
            SimpleDateFormat e = new SimpleDateFormat(format);
            return e.format(date);
        } catch (Exception var3) {
            return null;
        }
    }

    public static Date parseTime(String timeStr) {
        try {
            DateFormat e = TIME_FORMAT;
            synchronized(TIME_FORMAT) {
                return TIME_FORMAT.parse(timeStr);
            }
        } catch (ParseException var5) {
            return null;
        }
    }

    public static String formatMonth(Date date) {
        try {
            DateFormat e = MONTH_FORMAT;
            synchronized(MONTH_FORMAT) {
                return MONTH_FORMAT.format(date);
            }
        } catch (Exception var5) {
            return null;
        }
    }

    public static String formatYear(Date date) {
        try {
            DateFormat e = YEAR_FORMAT;
            synchronized(YEAR_FORMAT) {
                return YEAR_FORMAT.format(date);
            }
        } catch (Exception var5) {
            return null;
        }
    }

    public static String formatTime(Date date) {
        try {
            DateFormat e = TIME_FORMAT;
            synchronized(TIME_FORMAT) {
                return TIME_FORMAT.format(date);
            }
        } catch (Exception var5) {
            return null;
        }
    }

    public static Date getStartOfDay(Date day) {
        return getStartOfDay(day, Calendar.getInstance());
    }

    public static Date getStartOfDay() {
        return getStartOfDay((Date)null, Calendar.getInstance());
    }

    public static Date getStartOfWeek() {
        return getStartOfWeek((Date)null, Calendar.getInstance());
    }

    public static Date getStartOfWeek(Date day) {
        return getStartOfWeek(day, Calendar.getInstance());
    }

    public static Date getStartOfWeek(Date day, Calendar cal) {
        if (day == null) {
            day = new Date();
        }

        cal.setTime(day);
        cal.set(11, cal.getMinimum(11));
        cal.set(12, cal.getMinimum(12));
        cal.set(13, cal.getMinimum(13));
        cal.set(14, cal.getMinimum(14));
        int week = cal.get(7) - 1;
        week = week == 0 ? 7 : week;
        cal.add(5, 1 - week);
        return cal.getTime();
    }

    public static Date getStartOfDay(Date day, Calendar cal) {
        if (day == null) {
            day = new Date();
        }

        cal.setTime(day);
        cal.set(11, cal.getMinimum(11));
        cal.set(12, cal.getMinimum(12));
        cal.set(13, cal.getMinimum(13));
        cal.set(14, cal.getMinimum(14));
        return cal.getTime();
    }

    public static Date getEndOfDay(Date day) {
        return getEndOfDay(day, Calendar.getInstance());
    }

    public static Date getEndOfDay() {
        return getEndOfDay((Date)null, Calendar.getInstance());
    }

    public static Date getEndOfWeek(Date day) {
        return getEndOfWeek(day, Calendar.getInstance());
    }

    public static Date getEndOfWeek() {
        return getEndOfWeek((Date)null, Calendar.getInstance());
    }

    public static Date getEndOfWeek(Date day, Calendar cal) {
        if (day == null) {
            day = new Date();
        }

        cal.setTime(day);
        cal.set(11, cal.getMaximum(11));
        cal.set(12, cal.getMaximum(12));
        cal.set(13, cal.getMaximum(13));
        cal.set(14, cal.getMaximum(14));
        int week = 7 - cal.get(7);
        week = week == 6 ? 0 : week + 1;
        cal.add(5, week);
        return cal.getTime();
    }

    public static Date getEndOfDay(Date day, Calendar cal) {
        if (day == null) {
            day = new Date();
        }

        cal.setTime(day);
        cal.set(11, cal.getMaximum(11));
        cal.set(12, cal.getMaximum(12));
        cal.set(13, cal.getMaximum(13));
        cal.set(14, cal.getMaximum(14));
        return cal.getTime();
    }

    public static Date getStartOfHour(Date day) {
        return getStartOfHour(day, Calendar.getInstance());
    }

    public static Date getStartOfHour() {
        return getStartOfHour((Date)null, Calendar.getInstance());
    }

    public static Date getStartOfHour(Date day, Calendar cal) {
        if (day == null) {
            day = new Date();
        }

        cal.setTime(day);
        cal.set(12, cal.getMinimum(12));
        cal.set(13, cal.getMinimum(13));
        cal.set(14, cal.getMinimum(14));
        return cal.getTime();
    }

    public static Date getEndOfHour(Date day) {
        return getEndOfHour(day, Calendar.getInstance());
    }

    public static Date getEndOfHour() {
        return getEndOfHour((Date)null, Calendar.getInstance());
    }

    public static Date getEndOfHour(Date day, Calendar cal) {
        if (day == null) {
            day = new Date();
        }

        cal.setTime(day);
        cal.set(12, cal.getMaximum(12));
        cal.set(13, cal.getMaximum(13));
        cal.set(14, cal.getMaximum(14));
        return cal.getTime();
    }

    public static void main(String[] args) {
        String s = "2014";
        System.out.println(stringToUtilDate(s));
    }

    public static int getMonthDays(Date day) {
        if (day == null) {
            day = new Date();
        }

        Date lastDayOfMonth = getEndOfMonth(day);
        Calendar cal = Calendar.getInstance();
        cal.setTime(lastDayOfMonth);
        return cal.get(5);
    }

    public static Date getStartOfMinute() {
        return getStartOfMinute((Date)null, Calendar.getInstance());
    }

    public static Date getStartOfMinute(Date day) {
        return getStartOfMinute(day, Calendar.getInstance());
    }

    public static Date getStartOfMinute(Date day, Calendar cal) {
        if (day == null) {
            day = new Date();
        }

        cal.setTime(day);
        cal.set(13, cal.getMinimum(13));
        cal.set(14, cal.getMinimum(14));
        return cal.getTime();
    }

    public static Date getEndOfMinute() {
        return getEndOfMinute((Date)null, Calendar.getInstance());
    }

    public static Date getEndOfMinute(Date day) {
        return getEndOfMinute(day, Calendar.getInstance());
    }

    public static Date getEndOfMinute(Date day, Calendar cal) {
        if (day != null && cal != null) {
            cal.setTime(day);
            cal.set(13, cal.getMaximum(13));
            cal.set(14, cal.getMaximum(14));
            return cal.getTime();
        } else {
            return day;
        }
    }

    public static Date getStartOfMonth(Date day) {
        return getStartOfMonth(day, Calendar.getInstance());
    }

    public static Date getStartOfMonth() {
        return getStartOfMonth((Date)null, Calendar.getInstance());
    }

    public static Date getStartOfMonth(Date day, Calendar cal) {
        if (day == null) {
            day = new Date();
        }

        cal.setTime(day);
        cal.set(11, cal.getMinimum(11));
        cal.set(12, cal.getMinimum(12));
        cal.set(13, cal.getMinimum(13));
        cal.set(14, cal.getMinimum(14));
        cal.set(5, 1);
        return cal.getTime();
    }

    public static Date getEndOfMonth() {
        return getEndOfMonth((Date)null, Calendar.getInstance());
    }

    public static Date getEndOfMonth(Date day) {
        return getEndOfMonth(day, Calendar.getInstance());
    }

    public static Date getStartOfYear() {
        return getStartOfYear((Date)null, Calendar.getInstance());
    }

    public static Date getStartOfYear(Date day) {
        return getStartOfYear(day, Calendar.getInstance());
    }

    public static Date getStartOfYear(Date day, Calendar cal) {
        if (day == null) {
            day = new Date();
        }

        cal.setTime(day);
        cal.set(11, cal.getMinimum(11));
        cal.set(12, cal.getMinimum(12));
        cal.set(13, cal.getMinimum(13));
        cal.set(14, cal.getMinimum(14));
        cal.set(2, 0);
        cal.set(5, cal.getMinimum(5));
        return cal.getTime();
    }

    public static Date getEndOfYear() {
        return getEndOfYear((Date)null, Calendar.getInstance());
    }

    public static Date getEndOfYear(Date day) {
        return getEndOfYear(day, Calendar.getInstance());
    }

    public static Date getEndOfYear(Date day, Calendar cal) {
        if (day == null) {
            day = new Date();
        }

        cal.setTime(day);
        cal.set(11, cal.getMaximum(11));
        cal.set(12, cal.getMaximum(12));
        cal.set(13, cal.getMaximum(13));
        cal.set(14, cal.getMaximum(14));
        cal.set(2, 11);
        cal.set(5, cal.getMaximum(5));
        return cal.getTime();
    }

    public static Date getEndOfMonth(Date day, Calendar cal) {
        if (day == null) {
            day = new Date();
        }

        cal.setTime(day);
        cal.set(11, cal.getMaximum(11));
        cal.set(12, cal.getMaximum(12));
        cal.set(13, cal.getMaximum(13));
        cal.set(14, cal.getMaximum(14));
        cal.set(5, 1);
        cal.add(2, 1);
        cal.add(5, -1);
        return cal.getTime();
    }

    public static int compare(String dateStr1, String dateStr2) {
        String dt = "2018-08-08";
        Date dt1 = parseTime(dt + dateStr1 + ":00");
        Date dt2 = parseTime(dt + dateStr2 + ":00");
        return dt1.before(dt2) ? 0 : 1;
    }

    static {
        DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd", Locale.CHINESE);
        HOUR_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH", Locale.CHINESE);
        MINUTE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINESE);
        TIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINESE);
        MONTH_FORMAT = new SimpleDateFormat("yyyy-MM", Locale.CHINESE);
        YEAR_FORMAT = new SimpleDateFormat("yyyy", Locale.CHINESE);
    }
}
