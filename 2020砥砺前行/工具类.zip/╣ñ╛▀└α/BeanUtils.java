import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class BeanUtils extends org.apache.commons.beanutils.BeanUtils {
    protected static final Log logger = LogFactory.getLog(BeanUtils.class);

    public BeanUtils() {
    }

    public static Field getDeclaredField(Object object, String propertyName) throws NoSuchFieldException {
        return getDeclaredField(object.getClass(), propertyName);
    }

    public static Field getDeclaredField(Class clazz, String propertyName) throws NoSuchFieldException {
        Class superClass = clazz;

        while(superClass != Object.class) {
            try {
                return superClass.getDeclaredField(propertyName);
            } catch (NoSuchFieldException var4) {
                logger.error(var4);
                superClass = superClass.getSuperclass();
            }
        }

        throw new NoSuchFieldException("No such field: " + clazz.getName() + '.' + propertyName);
    }

    public static Object forceGetProperty(Object object, String propertyName) throws NoSuchFieldException {
        Field field = getDeclaredField(object, propertyName);
        boolean accessible = field.isAccessible();
        field.setAccessible(true);
        Object result = null;

        try {
            result = field.get(object);
        } catch (IllegalAccessException var6) {
            logger.info("error wont' happen");
        }

        field.setAccessible(accessible);
        return result;
    }

    public static void forceSetProperty(Object object, String propertyName, Object newValue) throws NoSuchFieldException {
        Field field = getDeclaredField(object, propertyName);
        boolean accessible = field.isAccessible();
        field.setAccessible(true);

        try {
            field.set(object, newValue);
        } catch (IllegalAccessException var6) {
            logger.info("Error won't happen");
        }

        field.setAccessible(accessible);
    }

    public static Object invokePrivateMethod(Object object, String methodName, Object... params) throws NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        Class[] types = new Class[params.length];

        for(int clazz = 0; clazz < params.length; ++clazz) {
            types[clazz] = params[clazz].getClass();
        }

        Class var9 = object.getClass();
        Method method = null;
        Class accessible = var9;

        while(accessible != Object.class) {
            try {
                method = accessible.getDeclaredMethod(methodName, types);
                break;
            } catch (NoSuchMethodException var9) {
                logger.error(var9);
                accessible = accessible.getSuperclass();
            }
        }

        if (method == null) {
            throw new NoSuchMethodException("No Such Method:" + var9.getSimpleName() + methodName);
        } else {
            boolean var10 = method.isAccessible();
            method.setAccessible(true);
            Object result = method.invoke(object, params);
            method.setAccessible(var10);
            return result;
        }
    }

    public static List<Field> getFieldsByType(Object object, Class type) {
        ArrayList list = new ArrayList();
        Field[] fields = object.getClass().getDeclaredFields();
        Field[] var4 = fields;
        int var5 = fields.length;

        for(int var6 = 0; var6 < var5; ++var6) {
            Field field = var4[var6];
            if (field.getType().isAssignableFrom(type)) {
                list.add(field);
            }
        }

        return list;
    }

    public static Class getPropertyType(Class type, String name) throws NoSuchFieldException {
        return getDeclaredField(type, name).getType();
    }

    public static String getGetterName(Class type, String fieldName) throws NoSuchFieldException {
        Class clazz = getPropertyType(type, fieldName);
        return !clazz.getName().equals("boolean") && !clazz.equals(Boolean.class) ? "get" + StringUtil.capitalize(fieldName) : "is" + StringUtil.capitalize(fieldName);
    }

    public static Method getGetterMethod(Class<?> type, String fieldName) throws SecurityException, NoSuchFieldException {
        try {
            return type.getMethod(getGetterName(type, fieldName));
        } catch (NoSuchMethodException var3) {
            logger.error(var3.getMessage(), var3);
            return null;
        }
    }

    public static String getSetterName(String fieldName) {
        return "set" + StringUtil.capitalize(fieldName);
    }

    public static <T> void setBeanPropertyByName(T entity, String propertyName, String propertyValue) throws Exception {
        try {
            if (describe(entity).containsKey(propertyName)) {
                PropertyDescriptor e = new PropertyDescriptor(propertyName, entity.getClass());
                Class propertyType = e.getPropertyType();
                Method setMethod = e.getWriteMethod();
                if (propertyType == String.class) {
                    setMethod.invoke(entity, propertyValue);
                } else if (!StringUtil.isBlank(propertyValue)) {
                    if (propertyType == Long.class) {
                        setMethod.invoke(entity, Long.parseLong(propertyValue));
                    } else if (propertyType == Byte.class) {
                        setMethod.invoke(entity, Byte.parseByte(propertyValue));
                    } else if (propertyType == Integer.class) {
                        setMethod.invoke(entity, Integer.parseInt(propertyValue));
                    } else if (propertyType == Short.class) {
                        setMethod.invoke(entity, Short.parseShort(propertyValue));
                    } else if (propertyType == Float.class) {
                        setMethod.invoke(entity, Float.parseFloat(propertyValue));
                    } else if (propertyType == Double.class) {
                        setMethod.invoke(entity, Double.parseDouble(propertyValue));
                    } else if (propertyType == BigDecimal.class) {
                        setMethod.invoke(entity, new BigDecimal(propertyValue));
                    } else if (propertyType == Date.class) {
                        setMethod.invoke(entity, DateUtils.stringToUtilDate(propertyValue));
                    } else if (propertyType == java.sql.Date.class) {
                        setMethod.invoke(entity, DateUtils.stringToSqlDate(propertyValue));
                    }
                }
            }

        } catch (Exception var6) {
            throw new Exception("�����������Ƹ�POJO��ֵʱ�������쳣��[" + propertyName + ": " + propertyValue + "]");
        }
    }

    public static String separateClassName(String className, String separator, boolean lowerCase) {
        char[] ca = className.toCharArray();
        StringBuilder build = new StringBuilder("" + ca[0]);
        boolean lower = true;

        for(int i = 1; i < ca.length; ++i) {
            char c = ca[i];
            if (Character.isUpperCase(c) && lower) {
                build.append(separator);
                lower = false;
            } else if (!Character.isUpperCase(c)) {
                lower = true;
            }

            build.append(c);
        }

        String actionName = build.toString();
        if (lowerCase) {
            actionName = actionName.toLowerCase();
        }

        return actionName;
    }
}
