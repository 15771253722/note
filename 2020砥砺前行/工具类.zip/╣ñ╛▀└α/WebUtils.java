import com.alibaba.fastjson.JSONObject;

public class WebUtils {
    public WebUtils() {
    }

    public static String getFailureMessage(String message, Object result) {
        JSONObject o = new JSONObject();
        o.put("success", false);
        o.put("message", message);
        o.put("result", result);
        return o.toString();
    }

    public static String getFailureMessage(String message) {
        return getFailureMessage(message, "");
    }

    public static String getSuccuseMessage(String message, Object data) {
        JSONObject o = new JSONObject();
        o.put("success", true);
        o.put("message", message);
        o.put("data", data);
        return o.toString();
    }

    public static String getSuccuseMessage(String message) {
        return getSuccuseMessage(message, "");
    }
}
