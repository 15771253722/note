
import com.alibaba.fastjson.JSONObject;
import com.joshin.kacoo.common.Constants;
import com.joshin.kacoo.common.sysconfig.SysConfig;
import com.joshin.kacoo.common.utils.Md5Util;
import com.joshin.kacoo.core.domain.A;
import com.joshin.qsch.api.domain.QiNiu;
import com.mysql.jdbc.StringUtils;
import com.qiniu.util.Auth;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.*;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.PoolingClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.thymeleaf.util.MapUtils;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

/**
 * DreamUtil������
 */
@SuppressWarnings("unchecked")
public class DreamUtil {
    private static final Logger log = LoggerFactory.getLogger(DreamUtil.class);

    /**
     * �����ļ���:ʱ��+ԭ�ļ���
     *
     * @param fileName �ļ���
     * @return �µ��ļ���
     */
    public static String gettimesName(String fileName) {
        Random random = new Random();
        return random.nextInt(10000) + System.currentTimeMillis() + getFileExt(fileName);
    }

    /**
     * ��ȡ�ļ���չ��
     *
     * @return string
     */
    public static String getFileExt(String fileName) {
        return fileName.substring(fileName.lastIndexOf("."));
    }

    public static JSONObject commonPost(String url, Map<String, String> map) throws Exception {
        // ��������ĵĲ���
        List<NameValuePair> nvps = new ArrayList<>();

        List<String> keys = new ArrayList<>(map.keySet());
        Collections.sort(keys, String.CASE_INSENSITIVE_ORDER);
        for (String key : keys) {
            String val = map.get(key);
            nvps.add(new BasicNameValuePair(key, val));
            System.out.println(key + "=" + val);
        }

        DefaultHttpClient httpClient = new DefaultHttpClient();
        HttpPost httpPost = new HttpPost(url);

        // ���������header
        httpPost.addHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
        httpPost.setEntity(new UrlEncodedFormEntity(nvps, "utf-8"));

        // ִ������
        HttpResponse response = httpClient.execute(httpPost);

        String rtnstr = EntityUtils.toString(response.getEntity());
        System.out.println(rtnstr);
        JSONObject jsonObject = JSONObject.parseObject(rtnstr);

        return jsonObject;
    }

    public static JSONObject commonPut(String url, Map<String, String> map) throws Exception {
        // ��������ĵĲ���
        List<NameValuePair> nvps = new ArrayList<>();

        List<String> keys = new ArrayList<>(map.keySet());
        Collections.sort(keys, String.CASE_INSENSITIVE_ORDER);
        for (String key : keys) {
            String val = map.get(key);
            nvps.add(new BasicNameValuePair(key, val));
            System.out.println(key + "=" + val);
        }

        DefaultHttpClient httpClient = new DefaultHttpClient();
        HttpPut httpPost = new HttpPut(url);

        // ���������header
        httpPost.addHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
        httpPost.setEntity(new UrlEncodedFormEntity(nvps, "utf-8"));

        // ִ������
        HttpResponse response = httpClient.execute(httpPost);

        String rtnstr = EntityUtils.toString(response.getEntity());
        System.out.println(rtnstr);
        JSONObject jsonObject = JSONObject.parseObject(rtnstr);

        return jsonObject;
    }

    public static JSONObject commonDelete(String url) throws Exception {
        // ��������ĵĲ���

        DefaultHttpClient httpClient = new DefaultHttpClient();
        HttpDelete httpDelete = new HttpDelete(url);

        // ���������header
        httpDelete.addHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
        // ִ������
        HttpResponse response = httpClient.execute(httpDelete);
        String rtnstr = EntityUtils.toString(response.getEntity());
        System.out.println(rtnstr);
        JSONObject jsonObject = JSONObject.parseObject(rtnstr);
        return jsonObject;
    }

    public static JSONObject commonGet(String url) throws Exception {
        // ��������ĵĲ���

        DefaultHttpClient httpClient = new DefaultHttpClient();
        HttpGet httpDelete = new HttpGet(url);

        // ���������header
        httpDelete.addHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
        // ִ������
        HttpResponse response = httpClient.execute(httpDelete);
        String rtnstr = EntityUtils.toString(response.getEntity());
        System.out.println(rtnstr);
        JSONObject jsonObject = JSONObject.parseObject(rtnstr);
        return jsonObject;
    }

    // redis Key�ַ���ƴ��
    public static String rdsJoinKey(String... keys) {
        String joinKey = "";
        for (int i = 0; i < keys.length; i++) {
            joinKey = joinKey + "_" + keys[i];
        }

        return joinKey;
    }

    public static Map<String, Object> returnFailure(Map map, String msg) {
        map.put(A.CODE, "20002");
        map.put(A.MSG, msg);
        return map;
    }

    public static Map<String, Object> returnFailure(Map map) {
        return returnFailure(map, "����ʧ��");
    }

    public static Map<String, Object> returnFailure(Map map, Object data, String msg) {
        map.put(A.CODE, "20002");
        map.put(A.MSG, msg);
        map.put(A.DATA, data);
        return map;
    }

    public static Map<String, Object> returnError(Map map, Exception e) {
        map.put(A.CODE, "80002");
        map.put(A.MSG, "��������");
        log.info("", e);
        return map;
    }

    public static Map<String, Object> returnError(Map map, Exception e, String msg) {
        map.put(A.CODE, "80002");
        map.put(A.MSG, msg);
        log.info("", e);
        return map;
    }

    public static Map<String, Object> returnSuccess(Map map, Object data, String msg) {
        map.put(A.CODE, "10000");
        map.put(A.MSG, msg);
        map.put(A.DATA, data);
        return map;
    }

    public static Map<String, Object> returnSuccess(Map map, Object data) {
        map.put(A.CODE, "10000");
        map.put(A.MSG, "�����ɹ�");
        map.put(A.DATA, data);
        return map;
    }

    public static Map<String, Object> returnSuccess(Map map, String msg) {
        map.put(A.CODE, "10000");
        map.put(A.MSG, msg);
        return map;
    }

    public static Map<String, Object> returnSuccess(Map map) {
        map.put(A.CODE, "10000");
        map.put(A.MSG, "�����ɹ�");
        return map;
    }

    /**
     * �Ƿ���ж�
     *
     * @param map  ���ؽ��
     * @param strs ���������  1.strs={"a","b"},�ж�keyΪa��b��map�Ƿ�Ϊ��,���ؽ��a,b����Ϊ�գ�
     *             2.strs={"a:b","c:d"},�ж�keyΪa��c��map�Ƿ�Ϊ��,���ؽ��b,d����Ϊ�գ�Ϊ��ǰ�˸��û���ʾ�Ѻõ�
     * @return
     */
    public static Map<String, Object> checkNullParam(Map map, String... strs) {
        Map<String, Object> result = new HashMap<>();
        StringBuilder sb = new StringBuilder();
        for (String str : strs) {
            if (!StringUtil.isNullOrEmpty(sb))
                sb.append(",");
            if (str.indexOf(":") > -1) {
                String[] strings = new String[2];
                strings = str.split(":");
                if (StringUtil.isNullOrEmpty(map.get(strings[0]))) {
                    result.put(A.CODE, "30000");
                    result.put(A.MSG, sb.append(strings[1]) + "����Ϊ��");
                }
            } else {
                if (StringUtil.isNullOrEmpty(map.get(str))) {
                    result.put(A.CODE, "30000");
                    result.put(A.MSG, sb.append(str) + "����Ϊ��");
                }
            }
        }
        return result;
    }


    //ת����
    public static Map<String, Object> parseFen(Map map, String... strs) {
        return parseFen(map, 100, strs);
    }


    //ת����
    public static Map<String, Object> parseFen(Map map, int rate, String... strs) {
        Map<String, Object> result = map;
        for (String str : strs) {
            if (!StringUtil.isNullOrEmpty(map.get(str))) {
                DecimalFormat df = new DecimalFormat("######0");
                Double price = Double.parseDouble(map.get(str) + "") * rate;
                result.put(str, Integer.parseInt(df.format(price)));
            }
        }
        return result;
    }

    public static Map<String, Object> parseFen(Map map, double rate, String... strs) {
        Map<String, Object> result = map;
        for (String str : strs) {
            if (!StringUtil.isNullOrEmpty(map.get(str))) {
                DecimalFormat df = new DecimalFormat("######0");
                Double price = Double.parseDouble(map.get(str) + "") * rate;
                result.put(str, Integer.parseInt(df.format(price)));
            }
        }
        return result;
    }


    public static Map<String, Object> parseYuan(Map map, String... strs) {
        return parseYuan(map, "0.00", 100.0, strs);
    }

    public static Map<String, Object> parseYuan(Map map, String decimalFormat, Double rate, String... strs) {
        if (MapUtils.isEmpty(map)) {
            return map;
        }
        Map<String, Object> result = map;
        for (String str : strs) {
            if (StringUtil.isNullOrEmpty(map.get(str))) {
                result.put(str, 0.0);
            } else {
                decimalFormat = StringUtil.isNullOrEmpty(decimalFormat) ? "0.00" : decimalFormat;
                DecimalFormat df = new DecimalFormat(decimalFormat);
                Long number = Long.valueOf(String.valueOf(map.get(str)));
                result.put(str, df.format(number / rate));
            }
        }
        return result;
    }


    public static GZIPInputStream getReponse(String url) throws IOException {

        HttpClient httpClient = new DefaultHttpClient();
        HttpGet httpget = new HttpGet(url);
        String userAgent = UserAgentUtil.getUserAgents();
        httpget.setHeader("User-Agent", userAgent);
        HttpResponse response = httpClient.execute(httpget);
        HttpEntity entity = response.getEntity();
        InputStream inputs = entity.getContent();
        GZIPInputStream in = new GZIPInputStream(inputs);
        return in;
    }

    public static String findApType(String apname) {
        // ����
        //String value = "md_md1a-dex_ap_a154";

        return findMidString(apname, "md_", "_AP");
    }

    public static String findMidString(String apname, String beginstr, String endstr) {
        // ƥ�����
        String reg = beginstr + "(.*?)" + endstr;
        Pattern pattern = Pattern.compile(reg);

        // ���� �� ƥ����� �Ĳ���
        Matcher matcher = pattern.matcher(apname);

        if( matcher.find() ){
            // ����ǰ��������ַ�
            //System.out.println(matcher.group());
            // ������ǰ��������ַ�
            return matcher.group(1);
        }else{
            return null;
        }
    }

    public static void main(String[] args) {
        System.out.println(Md5Util.signMD5("13111111111" + "" + "665"));
    }

    public static Map<String, Object> getUserId(HttpServletRequest request, Map<String, Object> reqMap) {
        String uid = request.getAttribute(Constants.KACOO_MMBID) == null ? "" : String.valueOf(request.getAttribute(Constants.KACOO_MMBID));
        Map map = new HashMap();
        map.put(A.CODE, "9999");
        map.put(A.MSG, "�����µ�¼");
        if (StringUtil.isNullOrEmpty(uid)) {
            return map;
        }
        reqMap.put("uid", uid);
        return reqMap;
    }

    public static void putUpdator(Map<String, Object> reqMap, Object id) {
        if (!StringUtil.isNullOrEmpty(id)) {
            reqMap.put("updator", reqMap.get(Constants.KACOO_MMBID));
        } else {
            reqMap.put("creator", reqMap.get(Constants.KACOO_MMBID));
        }
    }

}
