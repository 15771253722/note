import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Collection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JsonUtil {
    private static JsonUtil instance = null;
    private static ObjectMapper mapper = null;
    private static final Logger logger = LoggerFactory.getLogger(JsonUtil.class);

    private JsonUtil() {
        mapper = (new ObjectMapper()).setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
        mapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
        mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    public static ObjectMapper getInstance() {
        if (instance == null) {
            Class var0 = JsonUtil.class;
            synchronized(JsonUtil.class) {
                if (instance == null) {
                    instance = new JsonUtil();
                }
            }
        }

        return mapper;
    }

    public static String toString(Object obj) {
        try {
            ObjectMapper objectMapper = getInstance();
            String json = objectMapper.writeValueAsString(obj);
            return json;
        } catch (Exception var3) {
            logger.error("JsonUtils toString error", var3);
            return null;
        }
    }

    public static byte[] toByte(Object obj) {
        try {
            ObjectMapper objectMapper = getInstance();
            byte[] json = objectMapper.writeValueAsBytes(obj);
            return json;
        } catch (Exception var3) {
            logger.error("JsonUtils toByte error", var3);
            return null;
        }
    }

    public static <T> T toBean(byte[] json, Class<T> cls) {
        try {
            ObjectMapper objectMapper = getInstance();
            T vo = objectMapper.readValue(json, cls);
            return vo;
        } catch (Exception var4) {
            logger.error("JsonUtils byte[] toBean error", var4);
            return null;
        }
    }

    public static <T> T toBean(String json, Class<T> cls) {
        try {
            ObjectMapper objectMapper = getInstance();
            T vo = objectMapper.readValue(json, cls);
            return vo;
        } catch (Exception var4) {
            logger.error("JsonUtils String toBean error Json {}", json, var4);
            return null;
        }
    }

    public static <T> T toList(String json, Class<?> cls) {
        try {
            getInstance();
            JavaType javaType = getCollectionType(ArrayList.class, cls);
            return mapper.readValue(json, javaType);
        } catch (Exception var3) {
            var3.printStackTrace();
            return null;
        }
    }

    public static JavaType getCollectionType(Class<? extends Collection> collectionClass, Class<?> elementClasses) {
        return mapper.getTypeFactory().constructCollectionType(collectionClass, elementClasses);
    }
}
