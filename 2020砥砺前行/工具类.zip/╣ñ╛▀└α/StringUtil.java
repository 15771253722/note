import org.apache.commons.lang3.StringUtils;

public class StringUtil extends StringUtils {
    public StringUtil() {
    }

    public static boolean isNullOrEmpty(Object obj) {
        return obj == null || obj.toString().length() == 0;
    }

    public static String objVal(Object obj) {
        return obj == null ? null : String.valueOf(obj);
    }
}