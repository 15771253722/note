import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.codec.digest.DigestUtils;

public class Md5Util {
    private static Md5Util instance;
    private static final String[] hexDigits = new String[]{"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f"};

    private Md5Util() {
    }

    public static String signModan(String signSrc) {
        try {
            String TRADER_MD5_KEY = "201704130000160004";
            String salt = getInstance().md5Digest(TRADER_MD5_KEY.getBytes("utf-8"));
            signSrc = signSrc + "&salt=" + salt;
            return getInstance().md5Digest(signSrc.getBytes("utf-8"));
        } catch (UnsupportedEncodingException var3) {
            var3.printStackTrace();
            return null;
        }
    }

    public static String signSixty(String signSrc) {
        try {
            String TRADER_MD5_KEY = "201704130000168886";
            String salt = getInstance().md5Digest(TRADER_MD5_KEY.getBytes("utf-8"));
            signSrc = signSrc + "&salt=" + salt;
            return getInstance().md5Digest(signSrc.getBytes("utf-8")).substring(8, 24);
        } catch (UnsupportedEncodingException var3) {
            var3.printStackTrace();
            return null;
        }
    }

    public static String signModanWithSalt(String signSrc, String key) {
        try {
            String salt = getInstance().md5Digest(key.getBytes("utf-8"));
            signSrc = signSrc + "&salt=" + salt;
            return getInstance().md5Digest(signSrc.getBytes("utf-8"));
        } catch (UnsupportedEncodingException var3) {
            var3.printStackTrace();
            return null;
        }
    }

    public static String signMD5(String signSrc) {
        try {
            String TRADER_MD5_KEY = "201704130000160004";
            signSrc = signSrc + "&key=" + TRADER_MD5_KEY;
            return getInstance().md5Digest(signSrc.getBytes("utf-8"));
        } catch (UnsupportedEncodingException var2) {
            var2.printStackTrace();
            return null;
        }
    }

    public static String signMachineMD5(String signSrc) {
        try {
            Date nowTime = new Date();
            SimpleDateFormat time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            signSrc = signSrc + time.format(nowTime);
            return getInstance().md5Digest(signSrc.getBytes("utf-8"));
        } catch (UnsupportedEncodingException var3) {
            var3.printStackTrace();
            return null;
        }
    }

    public static Md5Util getInstance() {
        return null == instance ? new Md5Util() : instance;
    }

    private String byteArrayToHexString(byte[] b) {
        StringBuffer resultSb = new StringBuffer();

        for(int i = 0; i < b.length; ++i) {
            resultSb.append(this.byteToHexString(b[i]));
        }

        return resultSb.toString();
    }

    private String byteToHexString(byte b) {
        int n = b;
        if (b < 0) {
            n = 256 + b;
        }

        int d1 = n / 16;
        int d2 = n % 16;
        return hexDigits[d1] + hexDigits[d2];
    }

    public String md5Digest(byte[] src) {
        MessageDigest alg;
        try {
            alg = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException var4) {
            return null;
        }

        return this.byteArrayToHexString(alg.digest(src));
    }

    public static String signMD5(String appKey, Map<String, String> map) {
        List<String> keys = new ArrayList(map.keySet());
        Collections.sort(keys, String.CASE_INSENSITIVE_ORDER);
        StringBuilder builder = new StringBuilder();
        Iterator var4 = keys.iterator();

        while(true) {
            String key;
            String val;
            do {
                if (!var4.hasNext()) {
                    builder.append(appKey);
                    String content = builder.toString();
                    System.out.println(content);
                    key = DigestUtils.md5Hex(content);
                    return key;
                }

                key = (String)var4.next();
                val = (String)map.get(key);
            } while("sign".equals(key));

            if (StringUtil.isBlank(val) || "null".equals(val)) {
                val = "";
            }

            builder.append(key + "=" + val);
            builder.append("&");
        }
    }

    public static void main(String[] args) {
        try {
            System.out.println(getInstance().md5Digest("111111".getBytes("iso8859-1")));
        } catch (UnsupportedEncodingException var2) {
            var2.printStackTrace();
        }

    }
}
